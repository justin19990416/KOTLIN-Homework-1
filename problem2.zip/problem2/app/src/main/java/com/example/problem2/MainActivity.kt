package com.example.problem2 // 套件名稱，決定此類別在專案中的命名空間 (namespace)

import android.graphics.Rect // 匯入 Rect，用來儲存 View 原始的 padding 值
import android.os.Bundle // 匯入 Bundle，Activity 生命週期 onCreate 的參數型別
import android.view.View // 匯入 View，存取根視圖與操作 padding
import androidx.activity.enableEdgeToEdge // 匯入 enableEdgeToEdge，快速開啟 Edge-to-Edge 顯示
import androidx.appcompat.app.AppCompatActivity // 匯入 AppCompatActivity，支援相容性好的 Activity 基底類
import androidx.core.view.ViewCompat // 匯入 ViewCompat，提供向後相容的 View 工具
import androidx.core.view.WindowInsetsCompat // 匯入 WindowInsetsCompat，存取系統列/鍵盤等 Insets
import androidx.core.view.updatePadding // 匯入擴充函式 updatePadding，便於更新個別邊的 padding

class MainActivity : AppCompatActivity() { // 宣告 MainActivity，繼承 AppCompatActivity
    override fun onCreate(savedInstanceState: Bundle?) { // 覆寫 onCreate，Activity 生命週期進入點
        super.onCreate(savedInstanceState) // 呼叫父類別 onCreate，完成基本初始化
        enableEdgeToEdge() // 啟用 Edge-to-Edge：內容可延伸至狀態列/導覽列下方

        setContentView(R.layout.activity_main) // 設定畫面佈局為 activity_main.xml

        val root: View = findViewById(R.id.main) // 取得根視圖（假設在 layout 中的根容器 id 為 main）

        val rootInitialPadding = root.recordInitialPadding() // 記錄根視圖原始 padding，避免之後覆蓋掉

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets -> // 設定 insets 監聽器，當系統列/鍵盤變化時回調
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars()) // 取得系統列（狀態列+導覽列）的各邊距
            v.updatePadding( // 以「原始 padding + 系統列 inset」的方式疊加，避免覆寫原有間距
                left   = rootInitialPadding.left   + systemBars.left, // 更新左側 padding
                top    = rootInitialPadding.top    + systemBars.top, // 更新頂部 padding（對應狀態列/瀏海）
                right  = rootInitialPadding.right  + systemBars.right, // 更新右側 padding
                bottom = rootInitialPadding.bottom + systemBars.bottom // 更新底部 padding（對應底部導覽列）
            )
            insets // 回傳 insets 讓子 View 仍可進一步處理（若有需要）
        }

        // --- 如果你的內容區需要因應鍵盤（IME）上推，建議對「內容 View」另外監聽（示意） ---
        // val list = findViewById<RecyclerView>(R.id.list) // 取得需要上推的內容區（例如 RecyclerView）
        // val listInitialPadding = list.recordInitialPadding() // 記錄列表原始 padding
        // ViewCompat.setOnApplyWindowInsetsListener(list) { v, insets -> // 對列表個別處理 insets
        //     val navIme = insets.getInsets( // 同時考慮底部導覽列與鍵盤（IME）露出時的 inset
        //         WindowInsetsCompat.Type.navigationBars() or WindowInsetsCompat.Type.ime()
        //     )
        //     v.updatePadding(bottom = listInitialPadding.bottom + navIme.bottom) // 只疊加「底部」padding 以便上推
        //     insets // 回傳 insets
        // }

        ViewCompat.requestApplyInsets(root) // 主動請求套用一次 insets，避免必須等互動才更新
    }
}

// ----- 工具函式區 -----

/**
 * 擴充函式：記錄目前 View 的原始 padding（避免後續覆寫時遺失）
 */
private fun View.recordInitialPadding(): Rect = // 對 View 加上擴充函式，回傳一個 Rect
    Rect(paddingLeft, paddingTop, paddingRight, paddingBottom) // 用當前四邊 padding 建立 Rect 物件
