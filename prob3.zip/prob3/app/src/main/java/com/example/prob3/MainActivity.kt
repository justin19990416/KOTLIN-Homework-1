package com.example.prob3 // 檔案實際所在套件；需與 Gradle namespace 對齊，否則 R 會找不到

import android.os.Bundle // 匯入 Bundle 型別，onCreate 會用到
import android.view.View // 匯入 View，取得根視圖與調整 padding
import android.widget.Button // 匯入 Button 控制項
import android.widget.EditText // 匯入 EditText 控制項
import android.widget.RadioGroup // 匯入 RadioGroup 控制項
import android.widget.TextView // 匯入 TextView 控制項
import androidx.activity.enableEdgeToEdge // 匯入 enableEdgeToEdge，啟用全螢幕內容
import androidx.appcompat.app.AppCompatActivity // 匯入 AppCompatActivity 基底類
import androidx.core.view.ViewCompat // 匯入 ViewCompat，處理 WindowInsets
import androidx.core.view.WindowInsetsCompat // 匯入 WindowInsetsCompat，取得系統列/鍵盤 Insets
import androidx.core.view.updatePadding // 匯入 updatePadding 擴充函式，方便只更新特定邊
import com.example.prob3.R // 明確匯入本 app 的 R（避免找錯命名空間）
import kotlin.random.Random // 匯入 Random，用於產生電腦出拳

class MainActivity : AppCompatActivity() { // 宣告主畫面的 Activity 類別
    override fun onCreate(savedInstanceState: Bundle?) { // 覆寫 onCreate：Activity 建立時呼叫
        super.onCreate(savedInstanceState) // 呼叫父類別初始化
        enableEdgeToEdge() // 啟用 edge-to-edge，內容可延伸到狀態列/導覽列

        setContentView(R.layout.activity_main) // 指定版面配置檔（需存在 res/layout/activity_main.xml）

        val root: View = findViewById(R.id.main) // 取得根容器（XML 的 @+id/main）
        val rootInitial = root.recordInitialPadding() // 紀錄原始 padding，避免後續覆蓋

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets -> // 設置 Insets 監聽器
            val sysBars = insets.getInsets(WindowInsetsCompat.Type.systemBars()) // 取得狀態列/導覽列 Insets
            val bottomNavIme = insets.getInsets( // 取得底部導覽列或鍵盤（IME）的可見 Insets
                WindowInsetsCompat.Type.navigationBars() or WindowInsetsCompat.Type.ime()
            )
            v.updatePadding( // 用「原始 padding + Insets」方式疊加
                left = rootInitial.left + sysBars.left, // 左側加入系統列左 Insets
                top = rootInitial.top + sysBars.top, // 上側加入狀態列高度（含瀏海）
                right = rootInitial.right + sysBars.right, // 右側加入系統列右 Insets
                bottom = rootInitial.bottom + bottomNavIme.bottom // 下側加入導覽列或鍵盤高度
            )
            insets // 回傳 insets 以便子 View 如需進一步處理
        }

        ViewCompat.requestApplyInsets(root) // 主動要求立即套用一次 Insets

        val edName = findViewById<EditText>(R.id.edName) // 取得姓名輸入框
        val tvText = findViewById<TextView>(R.id.tvText) // 取得提示文字
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup) // 取得出拳選項群組
        val btnMora = findViewById<Button>(R.id.btnMora) // 取得猜拳按鈕
        val tvName = findViewById<TextView>(R.id.tvName) // 取得名字顯示欄
        val tvWinner = findViewById<TextView>(R.id.tvWinner) // 取得勝利者顯示欄
        val tvMyMora = findViewById<TextView>(R.id.tvMyMora) // 取得我方出拳顯示欄
        val tvTargetMora = findViewById<TextView>(R.id.tvTargetMora) // 取得電腦出拳顯示欄

        btnMora.setOnClickListener { // 綁定按鈕點擊事件
            val playerName = edName.text.toString().trim() // 讀取姓名並去除前後空白
            if (playerName.isEmpty()) { // 檢查是否為空字串
                edName.error = "請輸入玩家姓名" // 在輸入框上顯示錯誤提示
                tvText.text = "請輸入玩家姓名" // 同步更新提示文字
                return@setOnClickListener // 中止後續流程
            }

            val myMora = when (radioGroup.checkedRadioButtonId) { // 依選取的單選鈕決定我方出拳
                R.id.btnScissor -> Mora.SCISSORS // 選剪刀
                R.id.btnStone -> Mora.ROCK // 選石頭
                R.id.btnPaper -> Mora.PAPER // 選布
                else -> Mora.SCISSORS // 保底（理論上不會到）
            }

            val targetMora = Mora.fromInt(Random.nextInt(3)) // 產生電腦出拳（0..2）

            tvName.text = "名字\n$playerName" // 顯示玩家名字
            tvMyMora.text = "我方出拳\n${myMora.toLabel()}" // 顯示我方出拳中文
            tvTargetMora.text = "電腦出拳\n${targetMora.toLabel()}" // 顯示電腦出拳中文

            when (decideWinner(myMora, targetMora)) { // 依出拳判斷勝負
                Result.DRAW -> { // 平手
                    tvWinner.text = "勝利者\n平手" // 顯示平手
                    tvText.text = "平局，請再試一次！" // 提示再來一局
                }
                Result.PLAYER -> { // 玩家勝
                    tvWinner.text = "勝利者\n$playerName" // 顯示玩家為勝利者
                    tvText.text = "恭喜你獲勝了！！！" // 恭喜訊息
                }
                Result.NPC -> { // 電腦勝
                    tvWinner.text = "勝利者\n電腦" // 顯示電腦為勝者
                    tvText.text = "可惜，電腦獲勝了！" // 鼓勵下次再挑戰
                }
            }
        }
    }
} // MainActivity 結束

private enum class Mora { // 列舉：三種出拳
    SCISSORS, // 剪刀
    ROCK, // 石頭
    PAPER; // 布

    companion object { // 伴生物件：提供靜態工廠方法
        fun fromInt(i: Int): Mora = when (i) { // 將 0/1/2 轉成對應出拳
            0 -> SCISSORS // 0 → 剪刀
            1 -> ROCK // 1 → 石頭
            else -> PAPER // 其他（含 2）→ 布
        }
    }
} // Mora 結束

private fun Mora.toLabel(): String = // 擴充函式：列舉轉中文標籤
    when (this) {
        Mora.SCISSORS -> "剪刀" // SCISSORS → 剪刀
        Mora.ROCK -> "石頭" // ROCK → 石頭
        Mora.PAPER -> "布" // PAPER → 布
    }

private enum class Result { // 勝負結果列舉
    DRAW, // 平手
    PLAYER, // 玩家勝
    NPC // 電腦勝
} // Result 結束

private fun decideWinner(me: Mora, npc: Mora): Result { // 判斷勝負並回傳結果
    if (me == npc) return Result.DRAW // 同手勢 → 平手
    return when { // 玩家勝利的三種情況
        me == Mora.SCISSORS && npc == Mora.PAPER -> Result.PLAYER // 剪刀勝布
        me == Mora.ROCK && npc == Mora.SCISSORS -> Result.PLAYER // 石頭勝剪刀
        me == Mora.PAPER && npc == Mora.ROCK -> Result.PLAYER // 布勝石頭
        else -> Result.NPC // 其餘 → 電腦勝
    }
} // decideWinner 結束

private data class InitialPadding( // 小資料類：封裝四邊 padding
    val left: Int, // 左 padding
    val top: Int, // 上 padding
    val right: Int, // 右 padding
    val bottom: Int // 下 padding
) // InitialPadding 結束

private fun View.recordInitialPadding(): InitialPadding = // 擴充函式：讀取當前 View 的四邊 padding
    InitialPadding(paddingLeft, paddingTop, paddingRight, paddingBottom) // 回傳封裝物件
